sysconfdir = "/opt/snlsp-firewall/etc/suricata/"
datarulesdir = "/opt/snlsp-firewall/share/suricata/rules"
localstatedir = "/opt/snlsp-firewall/var/run/suricata"

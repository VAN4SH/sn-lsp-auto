# Add SNLSP utils path
SNLSP_PATH=/opt/secretnet
export PATH=${SNLSP_PATH}/bin:${PATH}
[[ ${UID} == 0 ]] && PATH=${SNLSP_PATH}/sbin:${PATH}

# Workaround for locale in terminals
if [ -z "$LANG" ] ; then
    for i in /etc/default/locale /etc/sysconfig/i18n /etc/locale.conf "$HOME/.i18n" ; do
        [ -r "$i" ] && . "$i"
    done
fi
[ -n "$LANG" ] && export LANG || unset LANG
if [ -n "$LC_ALL" ] ; then
    [ "$LC_ALL" != "$LANG" ] && export LC_ALL || unset LC_ALL
else
    unset LC_ALL
fi

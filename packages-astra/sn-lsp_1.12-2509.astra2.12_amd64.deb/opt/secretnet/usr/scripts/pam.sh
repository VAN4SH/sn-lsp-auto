#!/usr/bin/env bash
source "$(dirname $0)/install/common.sh"

if [[ $1 == '1' ]]; then
    mode='enable'
elif [[ $1 == '0' ]]; then
    mode='disable'
else
    exit 1
fi

os_id="$(cat /etc/os-release | grep ^ID=)"
os_id_like="$(cat /etc/os-release | grep ID_LIKE)"

if which pam-auth-update; then
    auth_state_file='/opt/secretnet/etc/auth_state'
    current_mode=($(cat "${auth_state_file}"))
    [[ "${current_mode}" == "${mode}" ]] && exit 0

    gdm_group=''
    if [[ "${os_id}" =~ 'debian' ]]; then
        gdm_group='Debian-gdm'
    elif [[ "${os_id}" =~ 'ubuntu' ]]; then
        gdm_group='gdm'
    fi

    update_pam_config_debian "${mode}" "${gdm_group}"
    toggle_debian_pam_configs "${snlsp_pam_configs[*]}" "${mode}"
    if [[ "${mode}" == 'enable' ]]; then
        toggle_debian_pam_configs "${default_pam_configs[*]}" disable
    else
        toggle_debian_pam_configs "${default_pam_configs[*]}" enable
    fi

    echo "${mode}" > "${auth_state_file}"
elif which authselect; then
    update_pam_config_redhat_authselect "${mode}"
    toggle_authselect_pam_configs "${mode}"
elif [[ "${os_id}" =~ 'rhel' || "${os_id_like}" =~ 'rhel' ]]; then
    update_pam_config_redhat_legacy "${mode}"
    toggle_redhat_legacy_pam_configs
elif [[ "${os_id}" =~ 'altlinux' ]]; then
    update_pam_config_alt "${mode}"
elif [[ "${os_id}" =~ 'sle'[sd] ]]; then
    update_pam_config_sle "${mode}"
fi

exit 0

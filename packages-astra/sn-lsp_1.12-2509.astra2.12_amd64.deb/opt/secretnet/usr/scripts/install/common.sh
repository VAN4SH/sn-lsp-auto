[[ -z "${INSTALLOG}" ]] && INSTALLOG="/tmp/sn-install.log"
INSTALLPATH="/opt/secretnet"
SAVEPATH="$INSTALLPATH/var/install/save-config"

##############################################################################
# список модулей ядра SN LSP
SN_MOD_LIST="snbase.ko snaccess.ko sndelete.ko snmemory.ko snsecdev.ko snaudit.ko snenv.ko sobol.ko"
###############################################################################

backup_store () {
    if [[ "$1" = '' || "$2" = '' || "$1" = '/' ]]; then
        echo 'error params in backup_store'
        return 1
    fi

    if [[ "$3" = '' || "$3" = 'BAK' ]]; then
        cp -fp "$1" "$1.bak-sn" 1>> "${INSTALLOG}" 2>&1
    fi

    mkdir -p "${SAVEPATH}/$2"

    if [[ "$4" = '' || "$4" = 'COPY' ]]; then
        cp -fp "$1" "${SAVEPATH}/$2" 1>> "${INSTALLOG}" 2>&1
    else
        if [[ -d "$1" ]]; then
            mv -f "$1/"* "${SAVEPATH}/$2" 1>> "${INSTALLOG}" 2>&1
            rm -r "$1" 1>> "${INSTALLOG}" 2>&1
        else
            mv -f "$1" "${SAVEPATH}/$2" 1>> "${INSTALLOG}" 2>&1
        fi
    fi

    if [[ "$?" != 0 && -f "$1" ]]; then
        echo "Backup store error: $1" >> "${INSTALLOG}"
        return 1
    fi

    return 0
}

backup_restore () {
    if [[ "$1" = '' || "$2" = '' ]]; then
        echo 'error params in backup_restore'
        return 1
    fi

    if [[ ! -d "${SAVEPATH}/$1" ]]; then
        echo "warning: no savepath dir $1 - can\`t restore $2 ! deinstallation will continue" 1>> "${INSTALLOG}" 2>&1
        return 1
    fi

    if [[ "$2" != '' && "$2" != '/' ]]; then
        if [[ ! -d "$2" ]]; then
            rm -rf "$2" 1>> "${INSTALLOG}" 2>&1
            mkdir -p "$2" 1>> "${INSTALLOG}" 2>&1
        else
            if [[ "$4" = 'REPLACEDIR' ]]; then
                if [[ "$3" = 'MAKEBAK' ]]; then
                    mv -f "$2" "$2.bak"
                else
                    if [[ -h "$2" ]]; then
                        rm -f "$2"
                    else
                        rm -rf "$2"
                    fi
                fi

                mkdir -p "$2" 1>> "${INSTALLOG}" 2>&1
            fi
        fi

        for i in $(find "${SAVEPATH}/$1" -maxdepth 1 -type f 2>> /dev/null); do
            SN_FILENAME="$(basename "$i")"

            if [[ "$5" != '' && "$5" != "${SN_FILENAME}" ]]; then
                continue
            fi

            if [[ -e "$2/${SN_FILENAME}" ]]; then
                if [[ "$3" = 'MAKEBAK' ]]; then
                    mv -f "$2/${SN_FILENAME}" "$2/${SN_FILENAME}.bak"
                else
                    rm -f "$2/${SN_FILENAME}"
                fi
            fi

            mv -f "${SAVEPATH}/$1/${SN_FILENAME}" "$2" 1>> "${INSTALLOG}" 2>&1

            if [[ "$?" != 0 ]]; then
                echo "Backup restore error: $1" >> "${INSTALLOG}"
                return 1
            fi
        done
    fi

    return 0
}

create_log_dbs() {
    if [ ! -e /opt/secretnet/var/log/audit_logs.db ]; then
        sqlite3 /opt/secretnet/var/log/audit_logs.db < /opt/secretnet/usr/scripts/create_audit_logs_db 2>>"${INSTALLOG}"
    fi
    if [ ! -e /opt/secretnet/var/log/syslog_logs.db ]; then
        sqlite3 /opt/secretnet/var/log/syslog_logs.db < /opt/secretnet/usr/scripts/create_syslog_logs_db 2>>"${INSTALLOG}"
    fi
    chmod 600 /opt/secretnet/var/log/audit_logs.db  2>> "${INSTALLOG}"
    chmod 600 /opt/secretnet/var/log/syslog_logs.db 2>> "${INSTALLOG}"
    chmod 750 /opt/secretnet/var/log 2>> "${INSTALLOG}"
}

setup_aide_db() {
    "${INSTALLPATH}/bin/snaide" -i -c /opt/secretnet/etc/service/aide.conf 1>>"${INSTALLOG}" 2>&1

    AIDERESULT="$?"

    if [[ -f /opt/secretnet/usr/db/aide.db.new ]]; then
        mv -f /opt/secretnet/usr/db/aide.db.new /opt/secretnet/usr/db/aide.db 1>>"${INSTALLOG}" 2>&1
        AIDECOPYRESULT="$?"
    else
        AIDECOPYRESULT="1"
    fi

    "${INSTALLPATH}/bin/snaide" -i -c /opt/secretnet/etc/service/settings_aide.conf 1>> "${INSTALLOG}" 2>&1

    AIDERESULT2="$?"

    if [[ -f /opt/secretnet/usr/db/settings_aide.db.new ]]; then
        mv -f /opt/secretnet/usr/db/settings_aide.db.new /opt/secretnet/usr/db/settings_aide.db 1>>"${INSTALLOG}" 2>&1
        AIDECOPYRESULT2="$?"
    else
        AIDECOPYRESULT2="1"
    fi

    #initialize of functional control database
    "${INSTALLPATH}/sbin/snfc" -i 1>> "${INSTALLOG}" 2>&1
    SNFCRESULT="$?"

    if ! [[ "${AIDERESULT}" = "0" && "${AIDECOPYRESULT}" = "0" && "${AIDERESULT2}" = "0" && "${AIDECOPYRESULT2}" = "0" && "${SNFCRESULT}" = "0" ]]; then
        echo 'INTEGRITY_ERROR' 1>>"${INSTALLOG}" 2>&1
        return 1
    fi

    chmod 600 /opt/secretnet/etc/snfc.conf 1>>"${INSTALLOG}" 2>&1
    chmod 600 /opt/secretnet/etc/service/aide.conf 1>>"${INSTALLOG}" 2>&1
    chmod 600 /opt/secretnet/etc/service/settings_aide.conf 1>>"${INSTALLOG}" 2>&1

    return 0
}

fstab_addopts () {
    RET="0"
    #Добавляем acl в парамеры монтирования
    awk '
        BEGIN {
            DIRLIST["1"]="/";
            DIRLIST["2"]="/opt";
            DIRLIST["3"]="/home";
            DIRLIST["4"]="/var";
        }
        {

        if ($0 ~ "^#.*")
            print $0
        else {
            if (NF > 6) exit 1;
            FOUND=0;


            for (AA in DIRLIST) {
                if ($2 == DIRLIST[AA] && $3 != "xfs") {
                    FOUND=1;

                    if ($4 !~ /^acl$|^acl,|,acl,|,acl$/) {
                        printf("%s\t%s\t%s\t%s,acl\t%s\t%s\n",$1,$2,$3,$4,$5,$6);
                    } else
                        print $0;

                    break;
                }
            }

            if ( FOUND == 0 )
                print $0;

        }
    }' /etc/fstab > /tmp/fstab.new

    if [ "$?" != "0" ] ; then
        echo "fstab config error"
        return 1
    fi

    backup_store /etc/fstab etc NOBAK COPY

    mv -f /tmp/fstab.new /etc/fstab
    if [ "$?" != "0" ] ; then
        RET="2"
    fi
        chown root:root /etc/fstab
    if [ "$?" != "0" ] ; then
        RET="3"
    fi
    chmod u=rw,go=r /etc/fstab
    if [ "$?" != "0" ] ; then
        RET="4"
    fi

    # перемонтируем / с поддержкой ACL
    mount -o remount /opt 1>> $INSTALLOG 2>&1
    mount -o remount / 1>> $INSTALLOG 2>&1

    return $RET
}

simple_exit() {
    echo 'SIMPLE_EXIT' 1>> "${INSTALLOG}" 2>&1
    exit 1
}

suid_workaround() {

    local PREFIX=/opt/secretnet i RET=0

    # снимем все SUID
    find "${PREFIX}/bin" "${PREFIX}/sbin" "${PREFIX}/lib" -type f -exec chmod -s '{}' \; >/dev/null 2>&1 || RET=1

    # поставим на sbin
    #из util-linux
    local SBIN="unix_chkpwd"
    for i in ${SBIN}; do
        chmod -v u+s "/sbin/${i}" 1>>$INSTALLOG 2>&1 || true
        chmod -v u+s "/usr/sbin/${i}" 1>>$INSTALLOG 2>&1 || true
    done

    # поставим на bin
    #local BIN="chage chfn chsh expiry faillog gpasswd newgrp passwd mount umount su sudo pkexec"
    local BIN="chage chfn chsh expiry faillog gpasswd newgrp passwd mount umount su sudo"
    local BINDIRS="/bin /usr/bin"
    for i in ${BIN}; do
        for dir in ${BINDIRS}; do
            [[ -f "${dir}/${i}" ]] && chmod -v u+s "${dir}/${i}" 1>>"${INSTALLOG}" 2>&1 || true
        done
    done

    return $RET
}

addgroup () {
    groupadd -r $1 1>>$INSTALLOG 2>&1
    RETCODE="$?"
    if [ "$RETCODE" != "0" ] ; then
        SN_GROUPPRESENT_EXIT="1"

        if [ "$RETCODE" = "9" ] ; then
            SN_GROUPPRESENT_EXIT="0"
        fi

        if [ "$SN_GROUPPRESENT_EXIT" = "1" ] ; then
            return 1
        fi
    fi

    return 0
}

# поиск конфигурационного файла grub.cfg/grub.conf в системе
find_grub_cfg() {
    cfg_name=${1:-grub.cfg}
    cfg=$(find /boot -name $cfg_name)

    if [ "$(echo "$cfg" | wc -w)" -gt "1" ] ; then
        for f in $cfg ; do
            if grep -qwo 'generated by' $f ; then
                echo "$f"
                break
            fi
        done
    else
        echo "$cfg"
    fi
}

edit_snfc() {
    if [ -d /boot/grub2 ]; then
        sed -i '/boot\/grub[/$]/d' /opt/secretnet/etc/snfc.conf
    elif [ -d /boot/grub ]; then
        sed -i '/boot\/grub2[/$]/d' /opt/secretnet/etc/snfc.conf
    fi
}

grub_config() {
    RETCODE=0

    if [ -f /etc/sysconfig/grub2 ]; then
        cat /etc/sysconfig/grub2 | sed  -e "/^GRUB_CMDLINE_LINUX=/ {s|[\"']||g; s/selinux=[0-9][\t ]*//g; s/^\(GRUB_CMDLINE_LINUX=\)\(.*\)/\1\"\2 security=default\"/}; /^GRUB_CMDLINE_LINUX_DEFAULT=/ {s|[\"']||g; s/selinux=[0-9][\t ]*//g; s/^\(GRUB_CMDLINE_LINUX_DEFAULT=\)\(.*\)/\1\"\2 security=default\"/}" > /etc/sysconfig/grub2.new
        if [ "$?" != 0 ] ; then RETCODE=1; fi

        backup_store /etc/sysconfig/grub2 sysconfig NOBAK COPY

        mv -f /etc/sysconfig/grub2.new /etc/sysconfig/grub2
        if [ "$?" != 0 ] ; then RETCODE=1; fi

        chown root:root /etc/sysconfig/grub2
        if [ "$?" != 0 ] ; then RETCODE=1; fi
        chmod u=rw,go= /etc/sysconfig/grub2
        if [ "$?" != 0 ] ; then RETCODE=1; fi
    elif [ -f /etc/default/grub ]; then
        if [[ "$1" == 'with_parsec_parm' ]]; then
            cat /etc/default/grub | sed  -e "/^GRUB_CMDLINE_LINUX=/ {s|[\"']||g; s/^\(GRUB_CMDLINE_LINUX=\)\(.*\)/\1\"\2 parsec.ccnr_relax=1\"/}; /^GRUB_CMDLINE_LINUX_DEFAULT=/ {s|[\"']||g; s/^\(GRUB_CMDLINE_LINUX_DEFAULT=\)\(.*\)/\1\"\2 parsec.ccnr_relax=1\"/}" > /etc/default/grub.new
        else
            cat /etc/default/grub | sed  -e "/^GRUB_CMDLINE_LINUX=/ {s|[\"']||g; s/selinux=[0-9][\t ]*//g; s/^\(GRUB_CMDLINE_LINUX=\)\(.*\)/\1\"\2 security=default\"/}; /^GRUB_CMDLINE_LINUX_DEFAULT=/ {s|[\"']||g; s/selinux=[0-9][\t ]*//g; s/^\(GRUB_CMDLINE_LINUX_DEFAULT=\)\(.*\)/\1\"\2 security=default\"/}" > /etc/default/grub.new
        fi
        if [ "$?" != 0 ] ; then RETCODE=1; fi

        backup_store /etc/default/grub default NOBAK COPY

        mv -f /etc/default/grub.new /etc/default/grub
        if [ "$?" != 0 ] ; then RETCODE=1; fi

        chown root:root /etc/default/grub
        if [ "$?" != 0 ] ; then RETCODE=1; fi
        chmod u=rw,go= /etc/default/grub
        if [ "$?" != 0 ] ; then RETCODE=1; fi
    else
        echo "GRUB NOT FOUND"
        RETCODE=1
    fi

    grub_cfg=$(find_grub_cfg)
    if [ -n "$grub_cfg" ] ; then
        backup_store "$grub_cfg" grub NOBAK COPY
        echo "$grub_cfg" > $SAVEPATH/grub-cfg

        if [[ "$(which grub2-mkconfig)" != "" ]] ; then
            CMD_grub_mkconfig="grub2-mkconfig"
        else
            CMD_grub_mkconfig="grub-mkconfig"
        fi

        ${CMD_grub_mkconfig} > "${grub_cfg}.new" 2>> $INSTALLOG

        if [ "$?" != 0 ] ; then RETCODE=1; fi
        mv -f -- "${grub_cfg}.new" "${grub_cfg}"
        if [ "$?" != 0 ] ; then RETCODE=1; fi
        chown root:root -- "${grub_cfg}"
        if [ "$?" != 0 ] ; then RETCODE=1; fi
        chmod u=rw,go= -- "${grub_cfg}"
        if [ "$?" != 0 ] ; then RETCODE=1; fi
    else
        echo "File grub.cfg not found!" >> $INSTALLOG
        RETCODE=1
    fi

    edit_snfc

    if [ "$RETCODE" != "0" ] ; then
        echo "GRUB config error!"
    fi
    return 0
}

store_pam_config() {
    local services=($1)
    local source_dir="${2:-/etc/pam.d/}"
    if [[ "${source_dir}" == '/etc/pam.d/' ]]; then
        local backup_mode='BAK'
    else
        local backup_mode='NOBAK'
    fi

    for service in "${services[@]}"; do
        [[ -f "${source_dir}/${service}" ]] && \
            backup_store "${source_dir}/${service}" pam.d "${backup_mode}" COPY
    done
}

restore_pam_config() {
    local services=($1)
    local source_dir="${2:-/etc/pam.d/}"
    for service in "${services[@]}"; do
        [[ -f "${SAVEPATH}/pam.d/${service}" ]] && \
            backup_restore pam.d "${source_dir}" BAK NOREPLACEDIR "${service}"
    done
}

refresh_pam_config() {
    local services=($1)
    local source_dir="${2:-/etc/pam.d/}"
    for service in "${services[@]}"; do
        [[ -f "${SAVEPATH}/pam.d/${service}" ]] && \
            cp -f "${SAVEPATH}/pam.d/${service}" "${source_dir}"
    done
}

toggle_redhat_legacy_pam_configs() {
    local domain_modules=('pam_winbind.so' 'pam_sss.so')
    local available_domain_modules

    for module in "${domain_modules[@]}"; do
        if [[ -f "/lib64/security/${module}" ]]; then
            available_domain_modules+=("${module}")
        fi
    done

    local length=${#available_domain_modules[@]}
    let last_index=${length}-1

    # добавляем проверку localuser в auth секцию
    local insert_string="auth\t[success=$((${length} + 1)) default=ignore]\tpam_localuser.so"
    sed -i "/^auth.*strengthened_auth.*/i ${insert_string}" '/etc/pam.d/sn-auth-domain'
    for i in "${!available_domain_modules[@]}"; do
        # добавляем строку в секцию auth
        insert_string='auth\t'
        # контрол для последнего модуля в списке отличается
        if [[ $i != ${last_index} ]]; then
            let jump=${last_index}-$i
            insert_string+="[success=${jump} new_authtok_reqd=${jump} default=ignore]"
        else
            insert_string+="[success=ok new_authtok_reqd=ok default=1]"
        fi
        insert_string+="\t${available_domain_modules[$i]}"
        # аргументы для sss и winbind разные
        if [[ "${available_domain_modules[$i]}" == 'pam_sss.so' ]]; then
            insert_string+=" forward_pass"
        elif [[ "${available_domain_modules[$i]}" == 'pam_winbind.so' ]]; then
            insert_string+=" try_first_pass"
        fi
        sed -i "/^auth.*strengthened_auth.*/i ${insert_string}" '/etc/pam.d/sn-auth-domain'

        # добавляем строку в секцию account
        let jump=${length}-$i
        insert_string="account\t[success=${jump} default=ignore]"
        insert_string+="\t${available_domain_modules[$i]}"
        sed -i "/^account.*deny.*/i ${insert_string}" '/etc/pam.d/sn-auth-domain'

        # добавляем строку в секцию password
        insert_string="password\t[success=${jump} new_authtok_reqd=${jump} default=ignore]"
        insert_string+="\t${available_domain_modules[$i]} use_authtok"
        sed -i "/^password.*deny.*/i ${insert_string}" '/etc/pam.d/sn-auth-domain'
    done
}

redhat_legacy_services=('gdm-password' 'lightdm' 'xscreensaver' 'mate-screensaver' 'login' 'other'
                        'passwd' 'remote' 'sshd' 'su' 'sudo' 'cinnamon-screensaver')
store_pam_config_redhat_legacy() {
    store_pam_config "${redhat_legacy_services[*]}"
    store_pam_config 'sn-auth-domain'
}

restore_pam_config_redhat_legacy() {
    restore_pam_config "${redhat_legacy_services[*]}"
}

update_pam_config_redhat_legacy() {
    refresh_pam_config "${redhat_legacy_services[*]}"
    refresh_pam_config 'sn-auth-domain'
    [[ "$1" == 'disable' ]] && return

    if [[ -f /etc/pam.d/gdm-password ]]; then
        sed -i 's/password-auth/sn-system-auth/' /etc/pam.d/gdm-password
    fi
    if [[ -f /etc/pam.d/lightdm ]]; then
        sed -i 's/system-auth/sn-system-auth/' /etc/pam.d/lightdm
    fi
    if [[ -f /etc/pam.d/xscreensaver ]]; then
        cp -f /etc/pam.d/sn-xscreensaver /etc/pam.d/xscreensaver
    fi
    if [[ -f /etc/pam.d/mate-screensaver ]]; then
        sed -i '/^auth/ s/system-auth/sn-system-auth-lock/' /etc/pam.d/mate-screensaver
        sed -i '/^auth/b; s/system-auth/sn-system-auth/' /etc/pam.d/mate-screensaver
    fi
    if [[ -f /etc/pam.d/cinnamon-screensaver ]]; then
        sed -i '/^auth/ s/system-auth/sn-system-auth-lock/' /etc/pam.d/cinnamon-screensaver
        sed -i '/^auth/b; s/system-auth/sn-system-auth/' /etc/pam.d/cinnamon-screensaver
    fi
    for file in "${redhat_legacy_services[@]}"; do
        sed -i '/.*pam_nologin.so.*/d' "/etc/pam.d/${file}"
    done
    sed -i s/system-auth/sn-system-auth/ /etc/pam.d/login
    sed -i '/.*postlogin.*/d' /etc/pam.d/login
    sed -i "s/auth.*required.*pam_deny\.so/auth\trequired\t\/opt\/secretnet\/lib\/security\/pam_snauth\.so/" /etc/pam.d/other
    sed -i "s/password.*substack.*system-auth/password   include\tsn-system-auth/" /etc/pam.d/passwd
    sed -i 's/password-auth/sn-system-auth-notoken/' /etc/pam.d/sshd
    sed -i 's/system-auth/sn-system-auth-notoken/' /etc/pam.d/su
    sed -i 's/system-auth/sn-system-auth-notoken/' /etc/pam.d/sudo
}

enable_authselect_profile() {
    if authselect current &> /dev/null; then
        return
    fi

    if yes | net ads testjoin &> /dev/null; then
        authselect select winbind with-mkhomedir with-krb5 with-winbind-cache --force
        return
    fi

    authselect select sssd with-mkhomedir --force
}

toggle_authselect_pam_configs() {
    local current_profile='winbind'
    if authselect current; then
        current_profile="$(authselect current | awk 'BEGIN{FS=": "} NR==1{print $2}')"
    fi

    if [[ $1 == 'enable' ]]; then
        local new_profile="sn_${current_profile#sn_}"
    elif [[ $1 == 'disable' ]]; then
        local new_profile="${current_profile#sn_}"
    fi

    [[ "${current_profile}" == "${new_profile}" ]] && return

    local profiles=($(authselect list | awk '/^-/ { print $2 }'))
    [[ ! "${profiles[*]}" =~ "${new_profile}" ]] && return

    local saved_feature_list="${INSTALLPATH}/etc/authselect-features"
    local saved_features=($(cat "${saved_feature_list}"))
    local current_features=($(authselect current | awk '/^-/ { print $2 }'))
    printf "%s\n" "${current_features[@]}" > "${saved_feature_list}"

    authselect select "${new_profile}" --force
    for current_feature in "${current_features[@]}"; do
        authselect enable-feature "${current_feature}"
    done
    for saved_feature in "${saved_features[@]}"; do
        authselect enable-feature "${saved_feature}"
    done
}

redhat_authselect_services=('gdm-password' 'login' 'other' 'remote' 'sshd')
store_pam_config_redhat_authselect() {
    store_pam_config "${redhat_authselect_services[*]}"
}

restore_pam_config_redhat_authselect() {
    toggle_authselect_pam_configs disable
    restore_pam_config "${redhat_authselect_services[*]}"
}

update_pam_config_redhat_authselect() {
    refresh_pam_config "${redhat_authselect_services[*]}"
    [[ "$1" == 'disable' ]] && return

    sed -i "s/auth.*required.*pam_deny\.so/auth\trequired\t\/opt\/secretnet\/lib\/security\/pam_snauth\.so/" \
        /etc/pam.d/other

    for file in "${redhat_authselect_services[@]}"; do
        sed -i '/.*pam_nologin.so.*/d' "/etc/pam.d/${file}"
    done
}

# список конфликтующих модулей pam-configs
default_pam_configs=('cracklib' 'tally' 'pwquality')
snlsp_pam_configs=('snauth' 'sncracklib' 'snecho' 'snlastlog' 'snlog' 'sntally' 'sntoken')
toggle_debian_pam_configs() {
    local array=($1)
    if [[ $2 == 'enable' ]]; then
        local mode='/Default/s/no/yes/'
    elif [[ $2 == 'disable' ]]; then
        local mode='/Default/s/yes/no/'
    fi

    for module in "${array[@]}"; do
        [[ ! -f "/usr/share/pam-configs/${module}" ]] && continue
        sed -i "${mode}" "/usr/share/pam-configs/${module}" 1>>$INSTALLOG 2>&1
        backup_store "/usr/share/pam-configs/${module}" tmp NOBAK MOVE
    done

    pam-auth-update --package

    for module in "${array[@]}"; do
        backup_restore tmp /usr/share/pam-configs/ BAK NOREPLACEDIR "${module}"
    done

    pam-auth-update --package
}

debian_services=('gdm-password' 'lightdm' 'gdm-launch-environment' 'fly-dm' 'login')
store_pam_config_debian() {
    store_pam_config "${debian_services[*]}"
    store_pam_config "${default_pam_configs[*]}" '/usr/share/pam-configs/'
}

restore_pam_config_debian() {
    restore_pam_config "${debian_services[*]}"
    restore_pam_config "${default_pam_configs[*]}" '/usr/share/pam-configs/'
}

update_pam_config_debian() {
    refresh_pam_config "${debian_services[*]}"
    [[ "$1" == 'disable' ]] && return

    if [[ -f /etc/pam.d/gdm-password ]]; then
        sed -i -n '/user != root/{h;n;G};p' /etc/pam.d/gdm-password
        sed -i '/.*pam_nologin.so.*/i auth [success=1 default=ignore] pam_succeed_if.so quiet user ingroup snadmin' \
            /etc/pam.d/gdm-password
    fi
    if [[ -f /etc/pam.d/lightdm ]]; then
        sed -i '0,/auth/ s|auth|auth\t\trequisite\t/opt/secretnet/lib/security/pam_sn_token.so\nauth|' \
            /etc/pam.d/lightdm
        sed -i '/.*pam_nologin.so.*/i auth [success=1 default=ignore] pam_succeed_if.so quiet user ingroup snadmin' \
            /etc/pam.d/lightdm
    fi
    if [[ -f /etc/pam.d/gdm-launch-environment ]]; then
        local gdmgroup="$2"
        sed -i "/.*pam_nologin.so.*/i auth [success=1 default=ignore] pam_succeed_if.so quiet user ingroup ${gdmgroup}" \
            /etc/pam.d/gdm-launch-environment
    fi
    if [[ -f /etc/pam.d/fly-dm ]]; then
        sed -i '/.*pam_nologin.so.*/i auth [success=1 default=ignore] pam_succeed_if.so quiet user ingroup snadmin' \
            /etc/pam.d/fly-dm
    fi
    sed -i '/.*pam_nologin.so.*/i auth [success=1 default=ignore] pam_succeed_if.so quiet user ingroup snadmin' \
        /etc/pam.d/login
    sed -i '/.*pam_lastlog.so.*/d' /etc/pam.d/login
}

alt_services=('lightdm' 'sddm' 'kf5-screenlocker' 'mate-screensaver' 'login' 'passwd' 'sshd'
              'su' 'sudo')
store_pam_config_alt() {
    store_pam_config "${alt_services[*]}"
}

restore_pam_config_alt() {
    restore_pam_config "${alt_services[*]}"
}

update_pam_config_alt() {
    refresh_pam_config "${alt_services[*]}"
    [[ "$1" == 'disable' ]] && return

    if [[ -f /etc/pam.d/lightdm ]]; then
        sed -i '0,/auth/ s|auth|auth\t\trequisite\t/opt/secretnet/lib/security/pam_sn_token.so\nauth|' \
             /etc/pam.d/lightdm
        sed -i '/auth/s/common-login/sn-common-login-notoken/' /etc/pam.d/lightdm
        sed -i '/auth/!s/common-login/sn-common-login/' /etc/pam.d/lightdm
    fi
    if [[ -f /etc/pam.d/sddm ]]; then
        sed -i 's/common-login/sn-common-login-notoken/' /etc/pam.d/sddm
    fi
    if [[ -f /etc/pam.d/kf5-screenlocker ]]; then
        sed -i 's/system-auth/sn-system-auth-lock/' /etc/pam.d/kf5-screenlocker
    fi
    if [[ -f /etc/pam.d/mate-screensaver ]]; then
        sed -i 's/system-auth/sn-system-auth-lock/' /etc/pam.d/mate-screensaver
    fi
    sed -i '/.*pam_lastlog.so.*/d' /etc/pam.d/login
    sed -i 's/common-login/sn-common-login/' /etc/pam.d/login
    sed -i 's/system-auth/sn-system-auth/' /etc/pam.d/passwd
    sed -i 's/common-login-use_first_pass/common-login/' /etc/pam.d/sshd
    sed -i 's/common-login/sn-common-login-notoken/' /etc/pam.d/sshd
    sed -i 's/system-auth/sn-system-auth-notoken/' /etc/pam.d/su
    sed -i 's/system-auth/sn-system-auth-notoken/' /etc/pam.d/sudo
}

toggle_use_authtok_domain_module() {
    local domain_modules=('pam_sss.so' 'pam_winbind.so')
    for domain_module in "${domain_modules[@]}"; do
        local pam_string="$(grep "${domain_module}" "$2")"
        if [[ ! -z "${pam_string}" ]]; then
            if [[ "$1" == 'add' && ! "${pam_string}" =~ "use_authtok" ]]; then
                sed -i -e "/${domain_module}/ {s/$/use_authtok/}" "$2"
            elif [[ "$1" == 'remove' && "${pam_string}" =~ "use_authtok" ]]; then
                sed -i -e "/${domain_module}/ {s/use_authtok//}" "$2"
            fi
        fi
    done
}

toggle_sle_pam_configs() {
    local common_password_file='/etc/pam.d/common-password-pc'
    local module='cracklib'
    local argument_list="--${module}"
    local saved_feature_file="/opt/secretnet/etc/pam-features-${module}"
    if [[ $1 == 'enable' ]]; then
        local library="pam_${module}.so"
        if grep "${library}" "${common_password_file}"; then
            local current_features=("$(sed -n -e "s/\(^.*\)\(${library}[ \t]\)\(.*$\)/\3/p" "${common_password_file}")")
            printf "%s\n" "${current_features[@]}" > "${saved_feature_file}"

            pam-config -d "${argument_list}"
        fi

        toggle_use_authtok_domain_module add "${common_password_file}"
    elif [[ $1 == 'disable' ]]; then
        [[ -f "${saved_feature_file}" ]] || return

        local saved_features=($(cat "${saved_feature_file}"))
        for feature in "${saved_features[@]}"; do
            argument_list="${argument_list} --${module}-${feature}"
        done

        # pam-config сам удалит use_authtok (если он не предусмотрен его конфигурацией).
        # Самостоятельно лучше не удалять use_authtok, т.к. возможно он установлен по умолчанию,
        # как для pam_sss
        pam-config -a ${argument_list}
        rm -f "${saved_feature_file}"
    fi
}

sle_services=('gdm' 'login' 'passwd' 'remote' 'sshd' 'su' 'su-l' 'sudo' 'sudo-i')
store_pam_config_sle() {
    store_pam_config "${sle_services[*]}"
}

restore_pam_config_sle() {
    restore_pam_config "${sle_services[*]}"
}

update_pam_config_sle() {
    toggle_sle_pam_configs "$1"
    refresh_pam_config "${sle_services[*]}"
    [[ "$1" == 'disable' ]] && return

    for service in "${sle_services[@]}"; do
        if [[ -f "/etc/pam.d/${service}" ]]; then
            sed -i 's/\(common-.*\)/\1-sn/' "/etc/pam.d/${service}"
        fi
    done

    local nologin_jump_string='auth [success=1 default=ignore] pam_succeed_if.so quiet user ingroup'
    sed -i '/account.*pam_nologin.so.*/d' /etc/pam.d/sshd
    for service in 'gdm' 'login' 'remote' 'sshd'; do
        sed -i '/.*pam_lastlog.so.*/d' "/etc/pam.d/${service}"
        sed -i "/.*pam_nologin.so.*/i ${nologin_jump_string} snadmin" "/etc/pam.d/${file}"
    done
}

fix_root_path_alt() {
    backup_store /root/.bashrc etc BAK COPY
    sed -ri "s|(^PATH=)(.*)|\1${INSTALLPATH}/bin:${INSTALLPATH}/sbin:\2|" /root/.bashrc
}

restore_root_path_alt() {
    backup_restore etc /root/ BAK NOREPLACEDIR .bashrc
}

fix_systemd_units_alt8sp() {
    sed -i /After=/s/$/\ bind.service/ /lib/systemd/system/sn.service
}

install_passwdqc_conf() {
    backup_store /etc/passwdqc.conf etc BAK COPY 1>> "${INSTALLOG}" 2>&1
    cp -f "${INSTALLPATH}/etc/passwdqc.conf" /etc 1>> "${INSTALLOG}" 2>&1
}

uninstall_passwdqc_conf() {
    backup_restore etc /etc BAK NOREPLACEDIR passwdqc.conf
}

install_selinux_policy() {
    local policy='module_load.pp'
    semodule -i "/opt/secretnet/share/selinux/${policy}"
    [[ "$?" -ne 0 ]] && echo "Unable to install SELinux policy ${policy}" >> "${INSTALLOG}"
}

uninstall_selinux_policy() {
    local policy='module_load'
    semodule -r "${policy}" 1>> "${INSTALLOG}" 2>&1
    [[ "$?" -ne 0 ]] && echo "Unable to uninstall SELinux policy ${policy}" >> "${INSTALLOG}"
}

restore_selinux_context() {
    local paths=('/dev/snlog' '/opt/secretnet/' '/etc/pam.d/' '/usr/lib/cups/backend')
    for path in ${paths[@]}; do
        [[ -e "${path}" ]] && restorecon -R "${path}" 1>> "${INSTALLOG}" 2>&1
    done
}

install_selinux_policy_snlsp() {
    local policy='snlsp.pp'
    semodule -i "/opt/secretnet/share/selinux/${policy}"

    if [[ "$?" -ne 0 ]] ; then
        echo "Unable to install SELinux policy ${policy}" >> "${INSTALLOG}"
        return 1
    fi

    restore_selinux_context
    return 0
}

uninstall_selinux_policy_snlsp() {
    local policy='snlsp'
    semodule -r "${policy}" 1>> "${INSTALLOG}" 2>&1

    restore_selinux_context
}

add_snlogger_group () {
     # Создаем группу для регистрации событий
    if ! getent group snlogger &>/dev/null ; then
        addgroup snlogger
        RETCODE=$?
        if [ "$RETCODE" != "0" ] ; then
            echo "Error of add account" snlogger "$RETCODE" >> $INSTALLOG
            if [ "$FORCE" = "FALSE" ] ; then
                return 1
            fi
        fi
    fi
}

add_snadmin_group () {
    if ! getent group snadmin &>/dev/null ; then
        addgroup snadmin
        RETCODE=$?
        if [ "$RETCODE" != "0" ] ; then
            echo "Error of add account snadmin $RETCODE" >> $INSTALLOG
            if [ "$FORCE" = "FALSE" ] ; then
                return 1
            fi
        fi
    fi
}

add_admusers_in_snadmin() {
    local UID_MIN=$(awk '/^UID_MIN/ {print $2}' /etc/login.defs)
    UID_MIN=${UID_MIN:-500}

    local admgroup="$1"
    local admusers="$(getent group "${admgroup}" | cut -d: -f4 | sed 's/,/ /g')"
    for user in ${admusers}; do
        [ "$(id -u "${user}")" -ge "${UID_MIN}" ] && usermod -aG snadmin "${user}" 1>>${INSTALLOG} 2>&1
    done
}

remove_sns_groups () {
    for group in snlogger snadmin; do
        if getent group "${group}" &>/dev/null ; then
            groupdel "${group}" 1>> "${INSTALLOG}" 2>&1
        fi
    done
}

enable_kernel_modules() {
    local RETCODE=0
    for kernel in ${DEFINED_SYSTEMKERN[@]}; do
        if [[ -f "/boot/vmlinuz-${kernel}" ]]; then
            depmod -a "${kernel}" 1>>"${INSTALLOG}" 2>&1
            [[ "$?" != 0 ]] && ((RETCODE++))
        fi
    done

    return "${RETCODE}"
}

auth_policies_libsobol_path_fix() {
    sed -i 's|/opt/secretnet/lib/libsobol.so|/opt/secretnet/lib/sobol/libsobol.so|' \
        "${INSTALLPATH}/etc/auth_policies" 1>>$INSTALLOG 2>&1
}

enable_rcd_units() {
    cp -f /opt/secretnet/etc/rc.d/snstart.sysv_service /etc/init.d/snstart > /dev/null 2>&1
    cp -f /opt/secretnet/etc/rc.d/snservice.sysv_service /etc/init.d/snservice > /dev/null 2>&1
    cp -f /opt/secretnet/etc/rc.d/snswapwipe.sysv_service /etc/init.d/snswapwipe > /dev/null 2>&1

    update-rc.d snstart start 03 1 2 3 4 5 . stop 87 0 6 . 1>> "${INSTALLOG}" 2>&1
    update-rc.d snservice start 04 1 2 3 4 5 . stop 86 0 6 . 1>> "${INSTALLOG}" 2>&1
    update-rc.d snswapwipe stop 05 0 6 . 1>> "${INSTALLOG}" 2>&1
}

disable_rcd_units() {
    /etc/init.d/snservice stop 1>> "${INSTALLOG}" 2>&1
    /etc/init.d/snstart stop 1>> "${INSTALLOG}" 2>&1

    rm -f /etc/init.d/snservice /etc/init.d/snstart /etc/init.d/snswapwipe > /dev/null 2>&1

    update-rc.d snservice remove 1>> "${INSTALLOG}" 2>&1
    update-rc.d snstart remove 1>> "${INSTALLOG}" 2>&1
    update-rc.d snswapwipe remove 1>> "${INSTALLOG}" 2>&1
}

enable_systemd_units() {
    UNITS=('sn.service' 'snstart.service' 'snswapwipe.service' 'snkernel.service'
        'sntest.service')
    for i in "${UNITS[@]}"; do
        systemctl enable "${i}" 1>>"${INSTALLOG}" 2>&1
    done

    systemctl daemon-reload 1>>"${INSTALLOG}" 2>&1
}

# Remove cups settings from db
remove_cupsd_settings() {
    sqlite3 /opt/secretnet/usr/db/sn_settings.db "delete from service_mgr_conf where fsService = 'sncupsd'"
    sqlite3 /opt/secretnet/usr/db/sn_settings.db "delete from service_mgr_policies where fsService = 'sncupsd'"
    sqlite3 /opt/secretnet/usr/db/sn_settings.db "delete from service_mgr_conf where fsService = 'cupsd'"
    sqlite3 /opt/secretnet/usr/db/sn_settings.db "delete from service_mgr_policies where fsService = 'cupsd'"
}

update_cupsd_settings_to_systemctl() {
    sqlite3 /opt/secretnet/usr/db/sn_settings.db "update service_mgr_policies SET\
        fsStartCmd = '/bin/systemctl',\
        fsStartCmdArgs = 'start' || char(10) || 'cups',\
        fsStopCmd = '/bin/systemctl',\
        fsStopCmdArgs = 'stop' || char(10) || 'cups'\
        where fsService = 'cupsd'"
}

restore_grub_config() {

    if [ -f /etc/default/grub ]; then
        grub_cfg=/etc/default/grub
    elif [ -f /etc/sysconfig/grub2 ]; then
        grub_cfg=/etc/sysconfig/grub2
    else
        echo "GRUB NOT FOUND"
        return 1
    fi

    sed -i -e 's/\s*security=default//g' "${grub_cfg}"

    grub_cfg=$(find_grub_cfg)

    if [ -n "$grub_cfg" ] ; then
        if [[ "$(which grub2-mkconfig)" != "" ]] ; then
            CMD_grub_mkconfig="grub2-mkconfig"
        else
            CMD_grub_mkconfig="grub-mkconfig"
        fi

        $CMD_grub_mkconfig -o "${grub_cfg}"
    else
        echo "File grub.cfg not found!" >> $INSTALLOG
        return 1
    fi

    return 0
}

disable_sn_services() {
    local UNITS=( sn.service snstart.service )
    for i in "${UNITS[@]}" ; do
        systemctl stop "${i}" 1>>"${INSTALLOG}" 2>&1
    done

    UNITS=( sn.service snstart.service snswapwipe.service snkernel.service snxdm.service sntest.service snsable.service )
    for i in "${UNITS[@]}"
    do
        systemctl disable "${i}" 1>>"${INSTALLOG}" 2>&1
    done
    systemctl daemon-reload
}

disable_kernel_modules() {
    if [[ -n "$(lsmod | grep snbase)" ]]; then
        rmmod snbase >> "${INSTALLOG}" 2>&1
    fi
}

before_reboot_exit() {
    if [ "x$(echo ${LANG} | grep -ie "ru_RU.UTF[-]\?8")" != "x" ]; then
        notify="Пожалуйста, перезагрузите систему, чтобы завершить предыдущую операцию с Secret Net LSP..."
    else
        notify="Please reboot your system to complete previous operation with Secret Net LSP..."
    fi
    echo -e "\n\033[1m*** ${notify} \033[0m\n"

    exit 1
}

wait_for_snserv() {
    # Время на инициализацию snserv
    for (( i=1; i < 60; i++ )); do
        sleep 1s
        /opt/secretnet/bin/snbckctl -l &> /dev/null
        if [[ "$?" = 0 ]]; then
            echo 'backup_plugin started...' 1>> "${UPDATELOG}" 2>&1
            return 0
        fi
    done
    echo 'backup_plugin not started...' 1>> "${UPDATELOG}" 2>&1
    return 1
}

restore_sn_config() {
    echo 'Upgrade SN LSP' >> "${UPDATELOG}"

    # Загрузка модуля snbase
    if [[ -z "$(lsmod | grep snbase)" ]]; then
        grep -w kallsyms_on_each_symbol /proc/kallsyms > /opt/secretnet/var/tmp/kaddr
        grep -w kallsyms_lookup_name /proc/kallsyms >> /opt/secretnet/var/tmp/kaddr
        modprobe snbase >> "${UPDATELOG}" 2>&1
    fi

    # Запуск сервиса (необходимо для восстановления конфигурации)
    # init скрипт использовать не следует, так как он совершает лишние действия.
    /opt/secretnet/sbin/snserv --daemon >> "${UPDATELOG}" 2>&1
    if ! wait_for_snserv; then
        echo 'SecretNet LSP Settings cannot be recovered!' 1>> "${UPDATELOG}" 2>&1
        return 1
    fi
    # Восстановление последней конфигурации (сохраненной в %pre)
    echo 'Find last backup ID' >> "${UPDATELOG}"
    ID="$(/opt/secretnet/bin/snbckctl -l | grep -iE '^.*\bID\b.*:[[:space:]]+[[:digit:]]+$' |
        tail -n1 | sed 's/^.*:\s*\([0-9]\+$\)/\1/' 2>> "${UPDATELOG}")"
    if [[ -z "${ID}" ]]; then
        echo 'No backup found to restore' >> "${UPDATELOG}"
        return 1
    fi
    echo "Restore backup by ID: ${ID}" >> "${UPDATELOG}"
    /opt/secretnet/bin/snbckctl --id "${ID}" --restore=aec 1>> "${UPDATELOG}" 2>&1
    if [[ "$?" != 0 ]]; then
        echo 'AEC rules restore failed!' >> "${UPDATELOG}"
    fi
    /opt/secretnet/bin/snbckctl --force --id "${ID}" --restore=snsettings 1>> "${UPDATELOG}" 2>&1
    if [[ "$?" != 0 ]]; then
        echo 'Restore failed!' >> "${UPDATELOG}"
        return 1
    fi
    if ! wait_for_snserv; then
        echo 'SecretNet LSP Policies cannot be recovered!' 1>> "${UPDATELOG}" 2>&1
        return 1
    fi
    /opt/secretnet/bin/snbckctl --id "${ID}" --restore=policies 1>> "${UPDATELOG}" 2>&1
    if [[ "$?" != 0 ]]; then
        echo 'Policies restore failed!' >> "${UPDATELOG}"
    fi
    # Удаление последней конфигурации (сохраненной в %pre)
    echo "Delete backup by ID: ${ID}" >> "${UPDATELOG}"
    /opt/secretnet/bin/snbckctl --id "${ID}" --delete 1>> "${UPDATELOG}" 2>&1
    if [[ "$?" != 0 ]]; then
        echo 'Delete failed!' >> "${UPDATELOG}"
        return 1
    fi
    return 0
}

disable_sable() {
    echo "Disconnect board from Secret Net" 1>>"${INSTALLOG}" 2>&1
    /opt/secretnet/bin/snsablectl -d -f 1>>"${INSTALLOG}" 2>&1
}

add_snfc() {
    echo "Add $1 to integrity check default config" 1>>"${INSTALLOG}" 2>&1
    echo "$1 NORMALBACKLOCK" >> /opt/secretnet/etc/snfc.conf
}

# Ставит модули ядра на контроль; принимает список поддерживаемых ядер в виде аргумента
add_modules_to_integrity_check() {
    for kernel in $1; do
        for module in ${SN_MOD_LIST}; do
            add_snfc "/lib/modules/${kernel}/kernel/misc/${module}"
        done
    done
}

# Ищет и устанавливает конфиги по умолчанию для ЗПС для конкретной ОС
install_aec_configs() {
    # Формирует строку из строчных букв без пробелов, которая описывает ОС
    local lsb_rel="${1}"

    if [[ -z "${lsb_rel}" ]]; then
        lsb_rel="$(cat /etc/redhat-release 2>/dev/null || lsb_release -d 2>/dev/null)"
    fi

    if [[ -z "${lsb_rel}" ]]; then
        lsb_rel="$(grep PRETTY_NAME /etc/os-release 2>/dev/null)"
    fi
    if [[ -f /etc/terminal-release ]]; then
        lsb_rel="Terminal 1.2"
    fi
    # Понижает регистр и убирает пробелы
    local aec_os_name="$(echo "${lsb_rel}" | tr [:upper:] [:lower:] | sed 's/ //g')"

    # Поиск подходящих шаблонов
    cd /opt/secretnet/share/aec/templates
    for i in * ; do
        if [[ -d "${i}" ]]; then
            pattern="$(echo ${i} | sed 's/\([0-9]\+\.*[0-9]*\)/.*\1.*/')"
            if [[ "${aec_os_name}" =~ ${pattern} ]]; then
                cp -rf "/opt/secretnet/share/aec/templates/${i}/"* /opt/secretnet/etc/aec/
                echo "Copy AEC templates for ${i}" 1>>"${INSTALLOG}" 2>&1
                /opt/secretnet/bin/snaecctl reload 1>>"${INSTALLOG}" 2>&1
                return
            fi
        fi
    done
    /opt/secretnet/bin/snaecctl reload 1>>"${INSTALLOG}" 2>&1
    echo "AEC templates is not found! Use default templates." 1>>"${INSTALLOG}" 2>&1
}

install_sntemplate() {
    local template_dir='/tmp/sntemplate'
    if [[ -d "${template_dir}" ]]; then
        cp -rf "${template_dir}/aec" /opt/secretnet/etc 1>> "${INSTALLOG}" 2>&1
        cp -f "${template_dir}/auth_policies" /opt/secretnet/etc 1>> "${INSTALLOG}" 2>&1
        cp -f "${template_dir}/sn.db" /opt/secretnet/usr/db 1>> "${INSTALLOG}" 2>&1
        cp -f "${template_dir}/sn_settings.db" /opt/secretnet/usr/db 1>> "${INSTALLOG}" 2>&1
        rm -rf "${template_dir}"

        if [[ -n "$(echo "${LANG}" | grep -ie "ru_RU.UTF[-]\?8")" ]]; then
            local msg='Настройки Secret Net LSP успешно инициализированы из шаблона'
        else
            local msg='Secret Net LSP settings successfully initialized from template'
        fi
        echo -e "\n\033[1m*** ${msg} \033[0m\n"
    fi
}

#!/bin/bash

LOCK_RULE="/opt/secretnet/usr/scripts/udev/block-usb.rules"
HEARTBEAT_CMD="/opt/secretnet/bin/xscreensaver-command -deactivate >&- 2>&- &"
USER=$2
TMP_DEV_FILE=/opt/secretnet/var/tmp/usbhid
DEFINED_SYSTEMTYPE="none"

function get_distrib() {
    # Check OS version
    if [ -f /etc/continentos-release ] ; then
        DEFINED_SYSTEMTYPE="continentos4"
    elif [ -f /etc/redhat-release ] ; then
        lsb_rel=`cat /etc/redhat-release`
        if [[ $lsb_rel =~ "Red Hat" || $lsb_rel =~ "CentOS" ]] ; then
            if [[ $lsb_rel =~ " 6." ]] ; then
                DEFINED_SYSTEMTYPE="redhat6"
            elif [[ $lsb_rel =~ " 7." ]] ; then
                DEFINED_SYSTEMTYPE="redhat7"
            elif [[ $lsb_rel =~ " 8." ]] ; then
                DEFINED_SYSTEMTYPE="redhat8"
            else
                echo "Unsupported RHEL!"
                return 1
            fi
        elif [[ $lsb_rel =~ "MCBC" ]] ; then
            if [[ $lsb_rel =~ "5." ]] ; then
                DEFINED_SYSTEMTYPE="mcbc5"
            else
                echo "Unsupported MCBC!"
                return 1
            fi
        elif [[ $lsb_rel =~ "ALT" ]]; then
            if [[ $lsb_rel =~ "8 SP" ]]; then
                DEFINED_SYSTEMTYPE="alt8sp"
            elif [[ $lsb_rel =~ "K 9." ]] ; then
                DEFINED_SYSTEMTYPE="alt9k"
            elif [[ $lsb_rel =~ "9." ]] ; then
                DEFINED_SYSTEMTYPE="alt9"
            elif [[ $lsb_rel =~ "K 10." ]] ; then
                DEFINED_SYSTEMTYPE="alt10k"
            elif [[ $lsb_rel =~ "10." ]] ; then
                DEFINED_SYSTEMTYPE="alt10"
            elif [[ $lsb_rel =~ "SP" ]] ; then
                DEFINED_SYSTEMTYPE="alt10sp"
            else
                echo "Unsupported ALT!"
                return 1
            fi
        elif [[ $lsb_rel =~ "ROSA" ]]; then
            if [[ $lsb_rel =~ "7." ]]; then
                DEFINED_SYSTEMTYPE="rosa7"
            elif [[ $lsb_rel =~ "Enterprise Desktop X4" ]] ; then
                DEFINED_SYSTEMTYPE="rosa2016"
            elif [[ $lsb_rel =~ "12.5" ]] ; then
                DEFINED_SYSTEMTYPE="rosa2021"
            else
                echo "Unsupported ROSA!"
                return 1
            fi
        elif [ -f /etc/redos-release ] ; then
            DEFINED_SYSTEMTYPE="redos"
        else
            echo "Unsupported OS!"
            return 1
        fi
    elif [ -f /etc/astra_version ] ; then
        lsb_rel=`lsb_release -d`
        if [[ $lsb_rel =~ "Astra" ]] ; then
            if [[ $lsb_rel =~ "1.4" ]] ; then
                DEFINED_SYSTEMTYPE="astra14"
            elif [[ $lsb_rel =~ "1.5" ]] ; then
                DEFINED_SYSTEMTYPE="astra15"
            elif [[ $lsb_rel =~ "1.6" ]] ; then
                DEFINED_SYSTEMTYPE="astra16"
            else
                echo "Unsupported Astra!"
                return 1
            fi
        fi
    elif [ -f /etc/debian_version ]; then
        lsb_rel=`lsb_release -d`
        if [[ $lsb_rel =~ "Debian" ]]; then
            if [[ $lsb_rel =~ "7." ]]; then
                DEFINED_SYSTEMTYPE="debian7"
            elif [[ $lsb_rel =~ "8." ]] ; then
                DEFINED_SYSTEMTYPE="debian8"
            elif [[ $lsb_rel =~ "9." ]] ; then
                DEFINED_SYSTEMTYPE="debian9"
            elif [[ $lsb_rel =~ "10" ]] ; then
                DEFINED_SYSTEMTYPE="debian10"
            else
                echo "Unsupported Debian!"
                return 1
            fi
        elif [[ $lsb_rel =~ "Ubuntu" ]]; then
            if [[ $lsb_rel =~ "18." ]]; then
                DEFINED_SYSTEMTYPE="ubuntu18"
            elif [[ $lsb_rel =~ "20." ]]; then
                DEFINED_SYSTEMTYPE="ubuntu20"
            elif [[ $lsb_rel =~ "22." ]]; then
                DEFINED_SYSTEMTYPE="ubuntu22"
            else
                echo "Unsupported Ubuntu!"
                return 1
            fi
        elif [[ $lsb_rel =~ "Lotos" ]]; then
            DEFINED_SYSTEMTYPE="lotos"
        fi
    elif [[ -f /etc/SUSE-brand ]]; then
        lsb_rel="$(cat /etc/SUSE-brand)"
        if [[ $lsb_rel =~ "12" ]]; then
            DEFINED_SYSTEMTYPE="sle12"
        elif [[ $lsb_rel =~ "15" ]]; then
            DEFINED_SYSTEMTYPE="sle15"
        else
            echo "Unsupported SUSE!"
            return 1
        fi
    elif [[ -f /etc/os-release ]]; then
        lsb_rel="$(cat /etc/os-release | grep PRETTY_NAME)"
        if [[ "${lsb_rel}" =~ 'ALT' ]]; then
            if [[ "${lsb_rel}" =~ '10.' ]]; then
                DEFINED_SYSTEMTYPE="alt10"
            else
                echo "Unsupported ALT!"
                return 1
            fi
        else
            echo "Unsupported OS version!"
            return 1
        fi
    else
        echo "Unsupported OS version!"
        return 1
    fi
}

function xscreensaver_lock() {
    export DISPLAY=:0.0

    # check status
    status=`su ${USER} -c "/usr/bin/xscreensaver-command -time"`

    if [[ $status =~ "locked" ]]; then
        echo "Already locked"
    else
        su ${USER} -c "/usr/bin/xscreensaver-command -activate"

        touch ${lock_file}
    fi
}

function terminal_lock() {
    export DISPLAY=:0

    if [ -f /etc/udev/rules.d/block-usb.rules ]; then
        echo "Already locked"
        exit 0
    fi

    # Disable new usb devices
    cp $LOCK_RULE /etc/udev/rules.d/
    /sbin/udevadm control --reload-rules

    for host in /sys/bus/usb/devices/usb*; do
         echo 0 > $host/authorized_default;
    done

    # Disable usbhid devices
    for dev in /sys/bus/usb/drivers/usbhid/*; do
        if [ -d $dev ]; then
            echo -n $(basename "$dev") > /sys/bus/usb/drivers/usbhid/unbind
            echo $(basename "$dev") >> ${TMP_DEV_FILE}
    fi
    done

    # Activate xscreensaver
    xscreensaver_lock
}


function terminal_unlock() {
    # remove udev rule
    rm -f /etc/udev/rules.d/$(basename "$LOCK_RULE")
    /sbin/udevadm control --reload-rules

    for host in /sys/bus/usb/devices/usb*; do
        echo 1 > $host/authorized_default;
    done

    # Enable hid devices
    while read -r line
    do
        echo -n $line > /sys/bus/usb/drivers/usbhid/bind
    done < "${TMP_DEV_FILE}"
    rm ${TMP_DEV_FILE}
}

function gmome_screensaver_lock() {
    export DISPLAY=:0.0
    su ${USER} -c "/usr/bin/gnome-screensaver-command -l"
}

function debian7_lock() {
    kill -10 `pidof screenlock`
}

function unlock() {
    echo "not implemented"
}

function xscreensaver_start() {
    export DISPLAY=:0.0

    pidofproc xscreensaver
    if [[ $? != 0 ]]; then
        su ${USER} -c "/opt/secretnet/bin/xscreensaver -nosplash &"
    fi
}

function mcbc5_lock() {
    export DISPLAY=:0.0

    # Stop xlock
    pidofproc xlock
    if [[ $? == 0 ]]; then
        killall xlock
    fi

    xscreensaver_start
    xscreensaver_lock
}

function astra14_lock() {
    xscreensaver_start
    xscreensaver_lock
}

function rhel7_lock() {
    export XAUTHORITY="/var/run/lightdm/${USER}/xauthority"
    su ${USER} -c "/opt/secretnet/bin/keyX11 Super_L l"

    touch ${lock_file}
}

function mate_screensaver_lock() {

    local matescreensaver_pids="$(pidof mate-screensaver)"

    for i in ${matescreensaver_pids}; do
        if [[ -n "$(ps -U ${USER} -o pid | grep ${i})" ]]; then
            local matescreensaver_env="$(strings /proc/${i}/environ | grep DBUS_SESSION_BUS_ADDRESS=)"
            su ${USER} -c "${matescreensaver_env} mate-screensaver-command -l"
            return
        fi
    done
}

function gdbus_lock() {
    if [[ $1 == 'gdm' ]]; then
        local pids="$(pidof gnome-shell)"
        local dbus_de_string=gnome
    elif [[ $1 == 'kde4' ]]; then
        local pids="$(pidof kded4)"
        local dbus_de_string=freedesktop
    elif [[ $1 == 'kde5' ]]; then
        local pids="$(pidof kded5)"
        local dbus_de_string=freedesktop
    else
        echo "Unsupported gdbus option"
    fi

    for i in ${pids}; do
        if [[ -n "$(ps -U ${USER} -o pid | grep ${i})" ]]; then
            local dbus_env="$(strings /proc/${i}/environ | grep DBUS_SESSION_BUS_ADDRESS=)"
            su ${USER} -c "${dbus_env} gdbus call -e -d org.${dbus_de_string}.ScreenSaver -o /org/${dbus_de_string}/ScreenSaver -m org.${dbus_de_string}.ScreenSaver.Lock -t 1 > /dev/null 2>&1 &"
            return
        fi
    done
}


# Check OS version
get_distrib

if [ "$?" != "0" ] ; then
    exit 1
fi

# Check argumensts

# unlock
if [[ $1 == "--unlock" ]] ; then
    echo "Deprecated function"
fi

# lock
if [[ $1 == "--lock" ]] ; then
    echo $DEFINED_SYSTEMTYPE
    if [ "$DEFINED_SYSTEMTYPE" = "redhat6" ]; then
        gmome_screensaver_lock
    elif [ "$DEFINED_SYSTEMTYPE" = "continentos4" ]; then
        xscreensaver_lock
    elif [ "$DEFINED_SYSTEMTYPE" = "redhat7" ]; then
        rhel7_lock
    elif [ "$DEFINED_SYSTEMTYPE" = "redhat8" ]; then
        gdbus_lock gdm
    elif [ "$DEFINED_SYSTEMTYPE" = "debian8" ]; then
        xscreensaver_lock
    elif [ "$DEFINED_SYSTEMTYPE" = "debian9" ]; then
        rhel7_lock
    elif [ "$DEFINED_SYSTEMTYPE" = "debian10" ]; then
        gdbus_lock gdm
    elif [[ "$DEFINED_SYSTEMTYPE" =~ "sle" ]]; then
        gdbus_lock gdm
    elif [[ "$DEFINED_SYSTEMTYPE" =~ "ubuntu" ]]; then
        gdbus_lock gdm
    elif [ "$DEFINED_SYSTEMTYPE" = "mcbc5" ]; then
        mcbc5_lock
    elif [ "$DEFINED_SYSTEMTYPE" = "debian7" ]; then
        debian7_lock
    elif [ "$DEFINED_SYSTEMTYPE" = "astra14" ]; then
        astra14_lock
    elif [[ "$DEFINED_SYSTEMTYPE" = "rosa7" || "$DEFINED_SYSTEMTYPE" = "lotos" ||
            "$DEFINED_SYSTEMTYPE" = "alt9" || "$DEFINED_SYSTEMTYPE" = "redos" ||
            "$DEFINED_SYSTEMTYPE" = "alt8sp" || "$DEFINED_SYSTEMTYPE" = "alt10" ||
            "$DEFINED_SYSTEMTYPE" = "alt10sp" ]]; then
        pidof gnome-shell > /dev/null 2>&1
        if [[ $? == 0 ]]; then
            if [ "$DEFINED_SYSTEMTYPE" = "rosa7" ]; then
                gdbus_lock gdm
            else
                rhel7_lock
            fi
        else
            pidof mate-screensaver > /dev/null 2>&1
            if [[ $? == 0 ]]; then
                mate_screensaver_lock
            else
                echo "Unsupported graphical shell"
            fi
        fi
    elif [ "$DEFINED_SYSTEMTYPE" = "rosa2016" ]; then
        gdbus_lock kde4
    elif [[ "$DEFINED_SYSTEMTYPE" = "alt9k" || "$DEFINED_SYSTEMTYPE" = "alt10k" ||
            "$DEFINED_SYSTEMTYPE" = "rosa2021" ]]; then
        gdbus_lock kde5
    else
        echo "Not inplemented"
    fi
    exit 0
fi

echo "error : no arguments given.  Try this:"
echo -e "\t--lock\t\t- lock station"
echo -e "\t--unlock\t- unlock station"
exit 1
